const comprar = document.getElementById("comprarfre");

comprarfre.addEventListener("click", function(event){
event.preventDefault();
window.location.href="freegenC.html";
})