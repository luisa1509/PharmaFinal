const comprarmedi = document.getElementById("comprarmed");

comprarmed.addEventListener("click", function(event){
event.preventDefault();
window.location.href="medicaspC.html";
})
