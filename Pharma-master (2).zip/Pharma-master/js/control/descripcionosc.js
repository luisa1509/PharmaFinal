const comprarosc = document.getElementById("comprarosc");

comprarosc.addEventListener("click", function(event){
event.preventDefault();
window.location.href="oscilloC.html";
})