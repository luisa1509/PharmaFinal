const comprar = document.getElementById("comprar");

comprar.addEventListener("click", function(event){
event.preventDefault();
window.location.href="dolexC.html";
})








