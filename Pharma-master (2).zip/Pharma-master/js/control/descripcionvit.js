const comprarvit = document.getElementById("comprarvit");

comprarvit.addEventListener("click", function(event){
event.preventDefault();
window.location.href="vitaminaC.html";
})