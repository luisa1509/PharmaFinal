const comprarvan = document.getElementById("comprarvan");

comprarvan.addEventListener("click", function(eventvan){
eventvan.preventDefault();
window.location.href="vanartC.html";
})