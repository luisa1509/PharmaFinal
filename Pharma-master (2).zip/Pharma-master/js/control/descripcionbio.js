const comprarbio = document.getElementById("comprarbio");

comprarbio.addEventListener("click", function(event){
event.preventDefault();
window.location.href="biocalciumC.html";
})
