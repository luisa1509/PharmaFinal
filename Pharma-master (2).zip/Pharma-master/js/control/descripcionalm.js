const comprar = document.getElementById("compraralm");

compraralm.addEventListener("click", function(event){
event.preventDefault();
window.location.href="almiproC.html";
})