const comprardis = document.getElementById("comprardis");

comprardis.addEventListener("click", function(event){
event.preventDefault();
window.location.href="distranC.html";
})