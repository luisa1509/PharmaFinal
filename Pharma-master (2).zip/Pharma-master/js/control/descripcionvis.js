const comprarvis = document.getElementById("comprarvis");

comprarvis.addEventListener("click", function(event){
event.preventDefault();
window.location.href="visomegaC.html";
})
