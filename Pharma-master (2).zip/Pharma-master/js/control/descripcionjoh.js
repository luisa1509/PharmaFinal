const comprarjoh = document.getElementById("comprarjoh");

comprarjoh.addEventListener("click", function(event){
event.preventDefault();
window.location.href="johnsonC.html";
})
