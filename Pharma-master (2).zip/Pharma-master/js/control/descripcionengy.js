const comprar = document.getElementById("comprarengy");

comprarengy.addEventListener("click", function(event){
event.preventDefault();
window.location.href="engyC.html";
})