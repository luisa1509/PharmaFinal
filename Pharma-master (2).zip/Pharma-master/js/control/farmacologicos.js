const dolex= document.getElementById("dolex")

dolex.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="dolexD.html"
});

const distran= document.getElementById("distran")

distran.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="distranD.html"
});

const johnson= document.getElementById("johnson")

johnson.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="johnsonD.html"
});

const vanart= document.getElementById("vanart")

vanart.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="vanartD.html"
});

const medicasp= document.getElementById("medicasp")

medicasp.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="medicaspD.html"
});

const visomega= document.getElementById("visomega")

visomega.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="visomegaD.html"
});

const biocalcium= document.getElementById("biocalcium")

biocalcium.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="biocalciumD.html"
});

const oscillo= document.getElementById("oscillo")

oscillo.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="oscilloD.html"
});

const freegen= document.getElementById("freegen")

freegen.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="freegenD.html"
});

const vitamina= document.getElementById("vitamina")

vitamina.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="vitaminaD.html"
});

const almipro= document.getElementById("almipro")

almipro.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="almiproD.html"
});

const engy= document.getElementById("engy")

engy.addEventListener("click",function(event){
    event.preventDefault();
    window.location.href="engyD.html"
});

