class Usuario{

    constructor(id, name, password, direction){
        this.id=id;
        this.name= name;
        this.password=password;
        this.direction= direction;

    }

}