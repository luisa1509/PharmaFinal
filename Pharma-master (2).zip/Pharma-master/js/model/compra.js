class Compra{

    constructor(id, nombreProducto, precio,fecha){
        this.id=id;
        this.nombreProducto= nombreProducto;
        this.precio=precio;
        this.fecha=fecha;

    }

}