package com.example.afinal.model;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Producto implements Serializable {

    private String id;
    private String nombreProducto;
    private String precio;
    private String fecha;

    public Producto(String id, String nombreProducto, String precio, String fecha) {
        this.id = id;
        this.nombreProducto = nombreProducto;
        this.precio = precio;
        this.fecha = fecha;
    }

    public Producto() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombre) {
        this.nombreProducto = nombre;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }


    @NonNull
    @Override
    public String toString() {
        return nombreProducto +" "+ precio +" pedido el " + fecha;
    }
}
