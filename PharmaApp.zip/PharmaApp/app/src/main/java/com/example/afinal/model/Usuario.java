package com.example.afinal.model;

import java.io.Serializable;

public class Usuario implements Serializable {
    private String direction;
    private String id;
    private String name;
    private String password;

    public Usuario(String direction, String id, String name, String password) {
        this.direction = direction;
        this.id = id;
        this.name = name;
        this.password = password;
    }

    public Usuario() {
    }
    public String getDirection() {
        return direction;
    }
    public void setDirection(String direction) {
        this.direction = direction;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
}
