package com.example.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.afinal.model.Usuario;
import com.google.firebase.database.FirebaseDatabase;

public class Registro1 extends AppCompatActivity {

    private EditText nombreET;
    private EditText direccionET;
    private EditText contraET;
    private EditText confirmarContraET;
    private Button atras;
    private Button sigui;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro1);

        nombreET = findViewById(R.id.nombre);
        direccionET = findViewById(R.id.dire);
        sigui = findViewById(R.id.sigui);
        contraET =findViewById(R.id.contra);
        confirmarContraET = findViewById((R.id.confirmar));
        atras = findViewById(R.id.atras);

        sigui.setOnClickListener(
                (v)->{
                    String id= FirebaseDatabase.getInstance().getReference().child("Usuarios").push().getKey();

                    String nombre= nombreET.getText().toString();
                    String direccion =direccionET.getText().toString();
                    String contra = contraET.getText().toString();
                    String confirmar = contraET.getText().toString();



                    Usuario user = new Usuario(
                            direccion,id,nombre,contra
                    );

                    if (contra.equals(confirmar)){

                        FirebaseDatabase.getInstance().getReference()
                                .child("Usuarios").child(nombre).setValue(user);


                        Intent i = new Intent(this,Ingreso.class);
                        startActivity(i);

                    }
                    else {
                        Toast.makeText(Registro1.this, "contra no coincide", Toast.LENGTH_LONG).show();
                    }








                }
        );

        atras.setOnClickListener(
                (v)->{
                    Intent i = new Intent(this,Ingreso.class);
                    startActivity(i);

                }
        );

    }

}
