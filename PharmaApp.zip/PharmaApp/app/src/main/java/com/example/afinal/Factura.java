package com.example.afinal;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.afinal.model.Producto;
import com.example.afinal.model.Usuario;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class Factura extends AppCompatActivity {

    private ListView listaCompras;
    private ArrayAdapter<Producto> adapter;
    private ArrayList<Producto> productos;
    Usuario usuario;
    private String dato;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_factura);

        listaCompras= findViewById(R.id.listaCompras);

        productos=new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,productos);
        listaCompras.setAdapter(adapter);

        //recuperar informacion
       // usuario=(Usuario)getIntent().getExtras().getSerializable("usuario");

        dato = getIntent().getStringExtra("usuario");
        Toast.makeText(this, dato,Toast.LENGTH_SHORT ).show();


        listaCompras.setOnItemClickListener(
                (view, renglon,pos,id)->{
                    Producto producto =productos.get(pos);
                    Toast.makeText(this, producto.toString() +" Estado del envio: en camino",Toast.LENGTH_SHORT ).show();

                    //local storage

                   /* Intent i =new Intent(this,Detalles.class);
                    i.putExtra("producto",producto);//serializable
                    startActivity(i);

                    */
                }
        );


        FirebaseDatabase.getInstance().getReference().child("Usuarios").child(dato).child("compras")
                .addChildEventListener(new ChildEventListener() {


                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        Producto producto = dataSnapshot.getValue(Producto.class);
                        productos.add(producto);
                        adapter.notifyDataSetChanged();

                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                    });


}
}

