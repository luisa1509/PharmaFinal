package com.example.afinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.afinal.model.Usuario;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Ingreso extends AppCompatActivity {

    private EditText nombreET;
    private EditText contraET;
    private Button entrar;
    private Button registro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombreET = findViewById(R.id.nombre);
        contraET = findViewById(R.id.contra);
        entrar = findViewById(R.id.entrar);
        registro = findViewById(R.id.registro);


        entrar.setOnClickListener(
                (v)->{


                    String nombre= nombreET.getText().toString();
                    String contraseña =contraET.getText().toString();

                   // Toast.makeText(Ingreso.this, nombre, Toast.LENGTH_LONG).show();



                    FirebaseDatabase.getInstance().getReference().child("Usuarios").child(nombre).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                   Usuario user =  dataSnapshot.getValue(Usuario.class);

                                   // Toast.makeText(Ingreso.this, user.getName(), Toast.LENGTH_LONG).show();

                                    if(user == null){

                                        Toast.makeText(Ingreso.this, "el usuario no existe", Toast.LENGTH_LONG).show();
                                        return;

                                    }
                                    if(user.getPassword().equals(contraseña)){

                                        Intent i = new Intent(Ingreso.this, Factura.class);
                                        i.putExtra("usuario",user.getName());
                                        startActivity(i);


                                    }else{
                                        //No concuerda la contraseña


                                        Toast.makeText(Ingreso.this,"El usuario o la contraseña son incorrectos", Toast.LENGTH_LONG).show();
                                    }
                                }


                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                }
        );

        registro.setOnClickListener(
                (v)->{
                    Intent i = new Intent(Ingreso.this, Registro1.class);
                    startActivity(i);

                }
        );

    }
}
